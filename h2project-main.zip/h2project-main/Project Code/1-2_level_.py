from machine import ADC
from fifo import Fifo
from piotimer import Piotimer
from machine import UART, Pin, I2C, Timer, ADC
from ssd1306 import SSD1306_I2C
import time
from led import Led
import micropython
import utime

micropython.alloc_emergency_exception_buf(200)           
#OLED       
i2c = I2C(1, scl=Pin(15), sda=Pin(14), freq=400000)
oled_width = 128
oled_height = 64
oled = SSD1306_I2C(oled_width, oled_height, i2c)          
 
 
#VARIABLES 
button = Pin(12, pull=Pin.PULL_UP, mode=Pin.IN)
lamp = Led(20, brightness = 10)
pin_nr = 26
sample_rate = 250
threshold_percentage = 0.15
prev_sample = 0
peak_found = False 
current_peak_index = 0
previous_peak_index = 0
index = 0
ms_in_minute = 60000
min_hr = 30
max_hr = 240
first_peak_found = False
value_list = [0, 0, 0, 0, 0]
screen = "start"

class isr_adc:
    def __init__(self, adc_pin_nr):
        self.av = ADC(adc_pin_nr) # sensor AD channel
        self.fifo= Fifo(500) # fifo where ISR will put samples

    def handler(self, tid):
        self.fifo.put(self.av.read_u16())
        
        #calculating threshold
def threshold_fun(data):        
    max_value = max(data)
    min_value = min(data)
    amplitude = max_value - min_value
    threshold = max_value - 0.15 * amplitude
    
    return threshold
    
def hr_calculator(index, screen):
    ppi_samples = index - 1 # calculate ppi in number of samples
    ppi_ms = ppi_samples * 4 # 1 sample 4 ms
    hr =round(60000 / ppi_ms) # calculate heart rate in BPM
                    
    if hr >= min_hr and hr <= max_hr: # checking if HR is within the range
        print(hr)
        
        if screen == "measure":
            screen_update(hr)     
            
def screen_update(hr):
        lamp.on()
        oled.fill(0)
        screen_set()
        oled.text(str(hr), 50, 20, 1)
        oled.show()
        lamp.off() 

    
def screen_set():
    oled.fill(0)
    oled.text('HR:       BPM', 10, 20, 1)
    oled.text('Press button to', 0, 45, 1)
    oled.text('     STOP', 0, 55, 1)
 
def screen_start():
    oled.fill(0)
    oled.text('1.Please connect', 0, 20, 1)
    oled.text('   the sensor.', 0, 30, 1)
    oled.text('2.Press button', 0, 45, 1)
    oled.text('   to start.', 0, 55, 1)
    
#heart shape
def heart():
    oled.text('      ** **', 0, 0, 1)
    oled.text('     *  *  *', 0, 8, 1)
    oled.text('     *     *', 0, 16, 1)
    oled.text('      *   *', 0, 24, 1)
    oled.text('       * *', 0, 32, 1)
    oled.text('        *', 0, 40, 1)
    oled.text(' Group 3 Project', 0, 56, 1)
    oled.show()
    utime.sleep(3)
    oled.fill(0)
    oled.show()
 
adc = isr_adc(pin_nr)
heart()
tmr = Piotimer(mode = Piotimer.PERIODIC, freq = sample_rate, callback = adc.handler) # gets samples
time_prev = time.ticks_ms()
screen_start()

oled.show()

while True:
    if button.value() == 0:
        time_now = time.ticks_ms() # debouncing
                
        if time_now - time_prev >= 50:               
            if screen == "start":
                screen = "measure"
                screen_set()
                oled.show()
                            
            elif screen == "measure":
                screen = "start"
                screen_start()
                oled.show()
            
        time_prev = time_now
        
    # if fifo has data        
    if adc.fifo.has_data():
 
        value = adc.fifo.get()
        value_list.pop(0)
        value_list.append(value)
        mean_value = sum(value_list)/len(value_list)
            
        threshold = threshold_fun(adc.fifo.data)
            
            #check if we are above the threshold
        if mean_value > threshold:
                #start finding the peak
            if prev_sample > mean_value:  # found a peak
                if not peak_found:
                    if first_peak_found:
                        hr = hr_calculator(index, screen) 
                    
                    else:
                        first_peak_found = True
                
                peak_found = True
                index = -1 # the index will be zero before the next round
             
            # here we are below the threshold 
        else:
            peak_found = False
                                
        prev_sample = mean_value        
        index += 1