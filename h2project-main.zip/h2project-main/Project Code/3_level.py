import time
from machine import UART, Pin, I2C, Timer, ADC
from ssd1306 import SSD1306_I2C
from fifo import Fifo
from led import Led
from piotimer import Piotimer
import micropython
import utime
import network
from time import sleep
import mip
from umqtt.simple import MQTTClient
import ujson

micropython.alloc_emergency_exception_buf(200)
 
#VARIABLES 
button = Pin(12, pull=Pin.PULL_UP, mode=Pin.IN)
lamp = Led(20, brightness = 10)
pin_nr = 26
sample_rate = 250
threshold_percentage = 0.15
prev_sample = 0
peak_found = False 
current_peak_index = 0
previous_peak_index = 0
index = 0
ms_in_minute = 60000
min_hr = 30
max_hr = 240
first_peak_found = False
value_list = [0, 0, 0, 0, 0]
screen = "start"

class Encoder:
    def __init__(self, rot_a, rot_b):
        self.a = Pin(rot_a, mode = Pin.IN)
        self.b = Pin(rot_b, mode = Pin.IN)
        self.fifo = Fifo(30, typecode = 'i')
        self.a.irq(handler = self.handler_button, trigger = Pin.IRQ_RISING, hard = True)
    def handler_button(self, pin):
        if self.b():
            self.fifo.put(-1)
        else:
            self.fifo.put(1)
                        
class isr_adc:
    def __init__(self, adc_pin_nr):
        self.av = ADC(adc_pin_nr) # sensor AD channel
        self.fifo= Fifo(500) # fifo where ISR will put samples

    def handler(self, tid):
        self.fifo.put(self.av.read_u16())            
            
def selector(text, x, y, color):
    oled.text(text, x, y, color)
    oled.show()

def first_screen():
    oled.fill(0)
    oled.text('Press the button', 0, 20, 1)
    oled.text('   to start', 0, 30, 1)
    oled.show()  
    
def screen_menu():
    oled.fill(0)
    oled.text('Measure HR', 34, 2, 1)
    oled.text('HRV analysis', 34, 16, 1)
    oled.text(' Please rotate', 0, 45, 1)
    oled.text('button clockwise', 0,55, 1)
    selector('==>', 2, 2, 1)
    oled.show()
    
def screen_measure():
    oled.fill(0)
    oled.text('HR:       BPM', 10, 20, 1)
    oled.text('Press button to', 0, 45, 1)
    oled.text('     STOP', 0, 55, 1) 

def instruction():
    oled.fill(0)
    oled.text('- Place sensor ',0 , 0, 1)
    oled.text('- Press button', 0, 16, 1)
    oled.text('- Stay calm', 0, 32, 1)
    oled.text(' BTN here ====>', 0, 50, 1)
    oled.show()
    
def collecting_data():
    oled.fill(0)
    oled.text('Collecting data', 0, 20, 1)
    oled.text('      ...', 0, 30, 1)
    oled.show()
    
def sending_data():
    oled.fill(0)
    oled.text('  Sending data', 0, 20, 1)
    oled.text('      ...', 0, 30, 1)
    oled.show()    

def last_screen():
    oled.fill(0)
    oled.text('PPI:   ', 0, 0, 1)
    oled.text('HR:    ', 0, 12, 1)
    oled.text('RMSSD: ', 0, 24, 1)
    oled.text('SDNN:  ', 0, 36, 1)
    oled.text('Press the BTN =>', 0, 55, 1)
    oled.show()
    
def screen_thank_you():
    oled.fill(0)
    oled.text('    THANK YOU!', 0, 5, 1)
    oled.text('     Restart', 0, 20, 1)
    oled.text('   the program', 0, 30, 1)
    oled.text('    for a new', 0, 40, 1)
    oled.text('   measurement', 0, 50, 1)
    oled.show()   
    
def threshold_fun(data):        
    max_value = max(data)
    min_value = min(data)
    amplitude = max_value - min_value
    threshold = max_value - 0.15 * amplitude
    
    return threshold

def ppi_calculator(index):
    ppi_samples = index - 1 #| calculate ppi in number of samples
    ppi_ms = ppi_samples * 4 # 1 sample 4 ms
    return int(ppi_ms)
    
def hr_calculator(index, ppi_ms):
    ppi_samples = index - 1 #| calculate ppi in number of samples
    hr = round(60000 / ppi_ms) # calculate heart rate in BPM
                    
    if hr >= min_hr and hr <= max_hr: # checking if HR is within the range 
        print(hr)
        return int(hr)
            
def hr_calculator1(index, screen):
    ppi_samples = index - 1 #| calculate ppi in number of samples
    ppi_ms = ppi_samples * 4 # 1 sample 4 ms
    hr =round(60000 / ppi_ms) # calculate heart rate in BPM
                    
    if hr >= min_hr and hr <= max_hr: # checking if HR is within the range 
        print(hr)
        
        if screen == "measure":
            screen_update(hr)  # function    
            
def screen_update(hr):
        lamp.on()
        oled.fill(0)
        screen_measure()
        oled.text(str(hr), 50, 20, 1)
        oled.show()
        lamp.off()         
         
def rmssd_calculator(hr_list, ppi_list):
    # Calculate the differences between successive PPI values
    differences = [ppi_list[i + 1] - ppi_list[i] for i in range(len(ppi_list) - 1)]

    # Square the differences
    squared_diff = [diff ** 2 for diff in differences]

    # Calculate the mean of the squared differences
    mean_squared_diff = sum(squared_diff) / len(squared_diff)

    # Take the square root of the mean squared difference to get RMSSD
    rmssd = mean_squared_diff ** 0.5

    return int(rmssd)

def sdnn_calculator2(hr_list, ppi_list):
    # Calculate the mean of the HR values
    mean_hr = sum(hr_list) / len(hr_list)
    
    # Calculate the sum of squared differences from the mean for PPI
    sum_squared_diff_ppi = sum((x - mean_hr) ** 2 for x in ppi_list)
    
    # Calculate the variance for PPI
    variance_ppi = sum_squared_diff_ppi / len(ppi_list)
    
    # Calculate the standard deviation (SDNN) for PPI
    sdnn = variance_ppi ** 0.5
    
    return sdnn

def sdnn_calculator(hr_list, ppi_list):
    ppi_diff_list = []
    drop_th = 0.15
        
    ppi_mean = sum(ppi_list)/len(ppi_list)
    
    for ppi in ppi_list:
        if ppi >= ppi_mean - drop_th * ppi_mean and ppi <= ppi_mean + drop_th * ppi_mean:
            ppi_diff_list.append((ppi-ppi_mean)**2)
    
    mean_squared_ppi = sum(ppi_diff_list)/len(ppi_diff_list)
    sdnn = mean_squared_ppi**0.5
    
    return sdnn
         
    
SSID = "KME661_Group_3"
PASSWORD = "00000000"
BROKER_IP = "192.168.3.253"

# Function to connect to WLAN
def connect_wlan():
    # Connecting to the group WLAN
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID, PASSWORD)

    # Attempt to connect once per second
    while wlan.isconnected() == False:
        print("Connecting... ")
        sleep(1)

    # Print the IP address of the Pico
    print("Connection successful. Pico IP:", wlan.ifconfig()[0])
        
def connect_mqtt():
    mqtt_client=MQTTClient("", BROKER_IP)
    mqtt_client.connect(clean_session=True)
    return mqtt_client

def send_mqtt_message(mean_hr, mean_ppi, rmssd, sdnn):
    #Connect to WLAN
    connect_wlan()
            
    # Connect to MQTT
    try:
        mqtt_client=connect_mqtt()
        print("Connected to MQTT")
                                            
    except Exception as e:
        print(f"Failed to connect to MQTT: {e}")

    # Send MQTT message
    try:                  
        topic = "pico/test"
                                        
        measurement = {
                        "mean_hr": mean_hr,
                        "mean_ppi": mean_ppi,
                        "rmssd": rmssd,
                        "sdnn": sdnn
                        }
        json_message = ujson.dumps(measurement)
                                        
        mqtt_client.publish(topic, json_message)
                                        
        print(f"Sending to MQTT: {topic} -> {json_message}")
                                                
    except Exception as e:
        print(f"Failed to send MQTT message: {e}")
         
         
#heart shape
def heart():
    oled.fill(1)
    oled.text('      ** **', 0, 0, 0)
    oled.text('     *  *  *', 0, 8, 0)
    oled.text('     *     *', 0, 16, 0)
    oled.text('      *   *', 0, 24, 0)
    oled.text('       * *', 0, 32, 0)
    oled.text('        *', 0, 40, 0)
    oled.text(' Group 3 Project', 0, 56, 0)
    oled.show()
    utime.sleep(3)
    #oled.fill(0)
    #oled.show()
 
i2c = I2C(1, scl=Pin(15), sda=Pin(14), freq=400000)
oled_width = 128
oled_height = 64
oled = SSD1306_I2C(oled_width, oled_height, i2c)

first_screen()

adc = isr_adc(pin_nr)
rot = Encoder(10, 11)

line = 0
new_pos = 0
            
time_prev = time.ticks_ms()
position_list=[2, 16]

# set the first screen (appears once)
heart() 

tmr = Piotimer(mode = Piotimer.PERIODIC, freq = sample_rate, callback = adc.handler) # gets samples 
hr_list = []
ppi_list = []
screen_menu()

while True:
    if button.value() == 0:
        
        time_now = time.ticks_ms()
        if time_now - time_prev >= 100:
            
            if new_pos == 1 and screen == "start":
                screen = "measure"
                screen_measure()
                oled.show()
                
            elif new_pos == 0 and screen == "start":
                screen = "measure"
                screen_measure()
                oled.show()    
               
            elif screen == "measure":
                screen = "start"
                screen_thank_you()
                
                
            elif new_pos == 2 and screen == "start":
                screen = "instruction"
                instruction()
                    
            elif screen == "instruction":
                screen = "collecting"
                print("started collecting data")
                collecting_data()
                
            elif screen == "collecting":
                screen = "press the button"
                hr_list = []
                ppi_list = []
                
            elif screen == "final":
                screen_thank_you()
                
                                                 
        time_prev = time_now
        
    if rot.fifo.has_data():   
        value = rot.fifo.get()
        
        if value  == 1:
            new_line = line + value                   
                
            if new_line % 3 == 0:
                new_pos = 1
                prev_pos = 2
                
                if screen == "start":
                    selector('==>', 2, position_list[new_pos -1], 1)
                    selector('==>', 2, position_list[prev_pos - 1], 0)
                                    
            elif new_line % 3 == 1:                       
                prev_pos = 1
                new_pos = 2
                if screen == "start":
                    selector('==>', 2, position_list[new_pos -1], 1)
                    selector('==>', 2, position_list[prev_pos - 1], 0)   
                    
            line = new_line        
      
    if adc.fifo.has_data():
        value = adc.fifo.get()
        if screen == "collecting":
            value_list.pop(0)
            value_list.append(value)
            mean_value = sum(value_list)/len(value_list)
                
            threshold = threshold_fun(adc.fifo.data)             
                #check if we are above the threshold
            if mean_value > threshold:
                    #start finding the peak
                if prev_sample > mean_value:  # we have found a peak
                    if not peak_found:
                        if first_peak_found:
                            ppi_ms = ppi_calculator(index) #function
                            if sum(ppi_list) <= 5000: 
                                hr = hr_calculator(index, ppi_ms) # function
                                if hr is not None:
                                    hr_list.append(hr)
                                    ppi_list.append(ppi_ms)
                              
                            else:
                                #tmr.deinit()      
                                sending_data()
                                rmssd = round(rmssd_calculator(hr_list, ppi_list))
                                sdnn = round(sdnn_calculator(hr_list, ppi_list))
                                mean_hr = round(sum(hr_list)/len(hr_list))
                                mean_ppi = round(sum(ppi_list)/len(ppi_list))
                                print('Mean HR: ', mean_hr, 'Mean PPI: ', mean_ppi, 'RMSSD: ', rmssd, 'SDNN: ', sdnn)
                                last_screen()
                                screen = "final"
                                # oled screen
                                oled.text(str(mean_ppi), 56, 0, 1)
                                oled.text(str(mean_hr), 56, 12, 1)
                                oled.text(str(rmssd), 56, 24, 1)
                                oled.text(str(sdnn), 56, 36, 1)
                                oled.show()
                                
                                send_mqtt_message(mean_hr, mean_ppi, rmssd, sdnn)
                            
                    else:
                                first_peak_found = True
                        
                    peak_found = True
                    index = -1 # the index will be zero before the next round
          # here we are below the threshold 
            else:
                peak_found = False
                                        
            prev_sample = mean_value        
            index += 1
            
        elif screen == "measure":
            value_list.pop(0)
            value_list.append(value)
            mean_value = sum(value_list)/len(value_list)  
            threshold = threshold_fun(adc.fifo.data)
                
                #check if we are above the threshold
            if mean_value > threshold:
                    #start finding the peak
                if prev_sample > mean_value:  # we have found a peak
                    if not peak_found:
                        if first_peak_found:
                            hr = hr_calculator1(index, screen) # function
                        else:
                            first_peak_found = True
                    
                    peak_found = True
                    index = -1 # the index will be zero before the next round
                 
                # here we are below the threshold 
            else:
                peak_found = False
                                    
            prev_sample = mean_value        
            index += 1




