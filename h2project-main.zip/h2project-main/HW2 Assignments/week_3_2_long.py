'''Task 3.2
Implement a program that uses the rotary encoder to select an item from a menu. The menu has three
options: LED1, LED2, LED3. Encoder turns move the selection (arrow, highlight, etc.) and pressing the
button activates the selection. Activation turns toggles the selected LED on/off. The state of the LED
must be updated in the menu.
Use an interrupt for both turn detection and encoder button. The turn and press event must be sent to
the main program through a fifo. All of the menu logic must be in the main program.
The encoder button does not have hardware filtering so switch bounce filtering must be performed.
Bounce filtering should be done in the interrupt handler with the help of time.ticks_XXX-functions.
Filtering is done by taking a millisecond time stamp on each detected press and comparing that to the
timestamp of previous press. The new press is ignored if it is too close, for example less than 50 ms
away from the previous press.'''


import time
from machine import UART, Pin, I2C, Timer, ADC
from ssd1306 import SSD1306_I2C
from fifo import Fifo
from led import Led


button = Pin(12, pull=Pin.PULL_UP, mode=Pin.IN)
led = Pin(20, Pin.OUT)

class Encoder:
    def __init__(self, rot_a, rot_b):
        self.a = Pin(rot_a, mode = Pin.IN)
        self.b = Pin(rot_b, mode = Pin.IN)
        self.fifo = Fifo(30, typecode = 'i')
        self.a.irq(handler = self.handler, trigger = Pin.IRQ_RISING, hard = True)
    def handler(self, pin):
        if self.b():
            self.fifo.put(-1)
        else:
            self.fifo.put(1)
            
def selector(text, x, y, color):
    oled.text(text, x, y, color)
    oled.show()
    
    
def led1_off():
    oled.text('LED 1: ON', 35, 2, 0)
    oled.text('LED 1: OFF', 35, 2, 1)
    oled.show()
    
def led1_on():
    oled.text('LED 1: OFF', 35, 2, 0)
    oled.text('LED 1: ON ', 35, 2, 1)
    oled.show()
    
def led2_on():  
    oled.text('LED 2: OFF', 35, 16, 0)
    oled.text('LED 2: ON', 35, 16, 1)
    oled.show()
    
def led2_off():  
    oled.text('LED 2: ON', 35, 16, 0)
    oled.text('LED 2: OFF', 35, 16, 1)
    oled.show()
    
def led3_on():
    oled.text('LED 3: OFF', 35, 30, 0)
    oled.text('LED 3: ON', 35, 30, 1)
    oled.show()
    
def led3_off():
    oled.text('LED 3: ON', 35, 30, 0)  
    oled.text('LED 3: OFF', 35, 30, 1)
    oled.show()
  
            
i2c = I2C(1, scl=Pin(15), sda=Pin(14), freq=400000)
oled_width = 128
oled_height = 64
oled = SSD1306_I2C(oled_width, oled_height, i2c)            
            
rot = Encoder(10, 11)

time_prev = time.ticks_ms()

lamp1 = Led(22)
lamp2 = Led(21)
lamp3 = Led(20)
line = 0
new_pos = 0
            
oled.text('Please rotate', 15, 45, 1)
oled.text('button clockwise', 2,55, 1)
oled.show()
selector('==>', 2, 2, 1)
led1_off()
led2_off()
led3_off()

position_list=[2, 16, 30]
time_prev = time.ticks_ms()

while True:
    if button.value() == 0:
        time_now = time.ticks_ms()
        if time_now - time_prev >= 50:
            if new_pos == 1 or new_pos == 0:
                lamp1.toggle()
                if lamp1.value() == 1:
                    led1_on()
                elif lamp1.value() == 0:    
                    led1_off()
                   
            elif  new_pos == 2:
                lamp2.toggle()
                if lamp2.value() == 1:
                    led2_on()
                elif lamp2.value() == 0:    
                    led2_off()
                    
            elif  new_pos == 3:
                lamp3.toggle()
                if lamp3.value() == 1:
                    led3_on()
                elif lamp3.value() == 0:    
                    led3_off()                     
                    
        time_prev = time_now  
            
    if rot.fifo.has_data():
        value = rot.fifo.get()        
        if value  == 1:
            new_line = line + value                   
            #print('New line is', new_line, '  previous line is', line)
                
            if new_line % 3 == 0:
        
                new_pos = 1
                prev_pos = 3
                #print('In line 1')
                selector('==>', 2, position_list[new_pos -1], 1)
                selector('==>', 2, position_list[prev_pos - 1], 0)
                
                        
            elif new_line % 3 == 1:
                               
                prev_pos = 1
                new_pos = 2
                #print('In line 2')
                selector('==>', 2, position_list[new_pos -1], 1)
                selector('==>', 2, position_list[prev_pos - 1], 0)
                
                
            elif new_line % 3 == 2:            
                print("In line 3")
                prev_pos = 2
                new_pos = 3
                selector('==>', 2, position_list[new_pos -1], 1)
                selector('==>', 2, position_list[prev_pos - 1], 0)
            
                    
            line = new_line
     
     