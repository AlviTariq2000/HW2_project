from machine import Pin
from fifo import Fifo
from led import Led # from file led, import Led class
import time

class Encoder:
    def __init__(self, rot_a, rot_b, led_pin, button_pin):
        self.a = Pin(rot_a, mode = Pin.IN, pull = Pin.PULL_UP)
        self.b = Pin(rot_b, mode = Pin.IN, pull = Pin.PULL_UP)
        self.fifo = Fifo(30, typecode = 'i')
        self.a.irq(handler = self.handler, trigger = Pin.IRQ_RISING, hard = True)
        self.brightness = 1
        self.led = Led(led_pin, brightness = self.brightness)
        self.button = Pin(button_pin , mode= Pin.IN, pull = Pin.PULL_UP)
        
    
    def handler(self, pin):
        if self.b():
            self.fifo.put(-1)
        else:
            self.fifo.put(1)

rot = Encoder(10, 11, 21, 12)


while True:
    if rot.fifo.has_data(): #to check if there is any data
        turn = rot.fifo.get() # get one value from fifo
        if rot.led.value() == 1:
            rot.brightness += turn
            rot.led.brightness(rot.brightness)
        
    if rot.button.value() == 0: # if button is pushed, switch it ON
        rot.led.toggle()
        
        while rot.button.value() == 0:
            time.sleep_ms(10)
            
            
        
        
    
    
    
           
        
           

        
        
            
            
            
        

            
            
            
            
            
            
        
    
        
   
        
    
        
        



